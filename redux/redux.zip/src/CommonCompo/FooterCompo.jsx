import React from 'react';

const FooterCompo = () => {
    return (
        <>
            footer
        </>
    );
};

export default FooterCompo;