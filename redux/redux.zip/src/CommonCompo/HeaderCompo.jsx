import React from 'react';

const HeaderCompo = () => {
    return (
        <div>
            HeaderCompo
        </div>
    );
};

export default HeaderCompo;