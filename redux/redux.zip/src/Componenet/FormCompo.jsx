import React from 'react';

const FormCompo = () => {
    return (
        <>
            form / input /other
        </>
    );
};

export default FormCompo;