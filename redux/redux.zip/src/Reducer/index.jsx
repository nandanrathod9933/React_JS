import users from "./users.jsx"

import { combineReducers } from 'redux';

export default combineReducers({
    users
})