import React from 'react';
import { Navigate, createBrowserRouter } from 'react-router-dom';
import HomePage from './Pages/HomePage.jsx'


const Mainroutes = createBrowserRouter([
    {
        path: "/",
        element: <Navigate to="/home" replace />,
    }, {
        path: "/home",
        element: <HomePage />
    }
]);


export default Mainroutes;